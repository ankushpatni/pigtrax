var App = (function () {

  App.pageSignUp = function( ){
    'use strict'

    $('form').parsley();
    
  };

  return App;
})(App || {});
